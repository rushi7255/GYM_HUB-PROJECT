import equipments from "../images/equipments.jpeg";

const Equipments = () => {
  return (
    <div>
      <img src={equipments} class="img-fluid" alt="equipments_image"></img>
    </div>
  );
};

export default Equipments;
